var FileSet = new Class({
	
	Implements :[Options],
	
	options : {
		sets	: 'sets-wrapper', 
		setForm : 'set-form'
	},
	
	initialize : function(options) 
    {
		this.setOptions(options);
		this.slide 		= new Fx.Slide(this.options.sets);
		this.oid 		= document.id(this.options.sets).get('oid');
		this.file_id	= document.id(this.options.sets).get('file_id');
		this.baseURL 	= 'index.php?option=com_files';
    },
	
	show : function(){
		this.browse('selector');
	},
	
	hide : function(){
		this.browse('module');
	},
	
	browse : function(layout){
		
		this.slide.slideOut();
		
		var req = new Request.HTML({
			method  : 'get',
			url		: this.baseURL + '&view=sets&layout=' + layout + '&oid=' + this.oid + '&file_id=' + this.file_id,
			update	: this.options.sets,
			onComplete: function(el){
				this.slide.slideIn();
			}.bind(this)
		}).send();
	},
	
	add : function(){
		
		this.form = document.id(this.options.setForm);
		
		if(!this.form.get('validator').validate())
			return;
		
		this.form.ajaxRequest({
			method : 'post',
			url : this.form.get('action') + '&layout=selector_list&reset=1',
			data : this.form,
			inject : {
				element : document.getElement('#' + this.options.sets + ' .an-entities'),
				where   : 'top'
			},
			onSuccess : function(form){
				var element = document.getElement('#' + this.options.sets + ' .an-entities').getElement('.an-entity');
				this.form.reset();
			}.bind(this)
		}).send();
	},
	
	addFile : function(el){
		
		var entity = el;
		
		entity.ajaxRequest({
			method	: 'post',
			url		: this.baseURL + '&view=set&id=' + el.get('set_id').toInt() + '&file_id=' + this.file_id.toInt(),
			data	: 'action=addfile',
			onComplete : function()
			{
				entity.addClass('an-highlight');
				entity.set('data-trigger', 'RemoveFile');
			}
		}).send();
	},
	
	removeFile : function(el){
		
		var entity = el;
		
		el.ajaxRequest({
			method	: 'post',
			url		: this.baseURL + '&view=set&id=' + el.get('set_id').toInt() + '&file_id=' + this.file_id.toInt(),
			data	: 'action=removefile',
			onSuccess : function()
			{
				if(this.status == 205)
					entity.destroy();
				else
				{
					entity.removeClass('an-highlight');
					entity.set('data-trigger', 'AddFile');
				}	
			}
		}).send();
	}
});

var fileSet = new FileSet();

Delegator.register('click', {
	
	'SetSelector' : function(event, el, api) {
		event.stop();
		fileSet.show();
	},
	
	'CloseSelector' : function(event, el, api) {
		event.stop();
		fileSet.hide();
	},
	
	'RemoveFile' : function(event, el, api){
		event.stop();
		fileSet.removeFile(el);
	},
	
	'AddFile' : function(event, el, api){
		event.stop();
		fileSet.addFile(el);
	},
	
	'Add' : function(event, el, api){
		event.stop();
		fileSet.add();
	}
});