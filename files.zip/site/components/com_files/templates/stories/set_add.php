<?php defined('KOOWA') or die('Restricted access'); ?>

<data name="title">
	<?= sprintf(@text('COM-FILES-STORY-NEW-SET'), @name($subject), @route($object->getURL()), @possessive($target)) ?>
</data>

<data name="body">
	<?php if($object->title): ?>
	<h3 class="entity-title"><?= htmlspecialchars($object->title, ENT_QUOTES) ?></h3>
	<?php endif; ?>
	
	<?php if($object->description): ?>
	<div class="entity-description"><?= htmlspecialchars($object->description, ENT_QUOTES) ?></div>
	<?php endif; ?>
	
	<?php if ( $object->hasCover() ) : ?>
	<div class="entity-portrait-medium">
		<a href="<?= @route($object->getURL()) ?>">
			<img src="<?= $object->getCoverSource('medium') ?>" />
		</a>
	</div>
	<?php endif ?>
	
	<div data-behavior="Mediabox">
		<div class="media-grid">	
		<?php foreach( $object->files as $i=>$file ): ?>
			<?php 
			$rel = 'lightbox[actor-set-'.$file->owner->id.' 900 900]';
		
			$caption = htmlspecialchars($file->title, ENT_QUOTES).
			(($file->title && $file->description) ? ' :: ' : '').
			@helper('text.script', $file->description);
			?>
			<?php if ( $i > 12 ) break; ?>
			<div class="entity-portrait">
				<a rel="<?= $rel ?>" title="<?= $caption ?>" href="<?= $file->getPortraitURL('medium') ?>">
					<img src="<?= $file->getPortraitURL('square') ?>" />
				</a>
			</div>
		<?php endforeach; ?>
		</div>
	</div>
	
	<div class="entity-meta">
		<?= sprintf(@text('COM-FILES-SET-META-FILES'), $object->getFileCount()) ?>
	</div>
</data>
