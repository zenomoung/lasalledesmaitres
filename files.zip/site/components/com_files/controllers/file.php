<?php

/** 
 * LICENSE: Anahita is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 * 
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Controller
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @copyright  2008 - 2010 rmdStudio Inc./Peerglobe Technology Inc
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @version    SVN: $Id: view.php 13650 2012-04-11 08:56:41Z asanieyan $
 * @link       http://www.anahitapolis.com
 */

/**
 * File Controller
 *
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Controller
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @link       http://www.anahitapolis.com
 */
class ComFilesControllerFile extends ComMediumControllerDefault
{
	/**
	 * Browse Files
	 * 
	 * @param  KCommandContext $context
	 * @return void
	 */
	protected function _actionBrowse($context)
	{		
		$this->getService('repos://site/files.set');

		$files =  parent::_actionBrowse($context);
		
		$files->order('creationTime', 'DESC');
		
		if($this->exclude_set != '')
		{
			$set = $this->actor->sets->fetch(array('id'=>$this->exclude_set));	
			
			if(!empty($set))
			{
				$file_ids = array();
				foreach($set->files as $file)
					$file_ids[] = $file->id;
				
				if(count($file_ids))
					$files->where('file.id', '<>', $file_ids);
			}
		}
		
		return $files;
	}
	
	/**
	 * Method to upload and Add a file
	 *
	 * @param  KCommandContext $context
	 * @return void
	 */
	protected function _actionAdd($context)
  {
     $entity = parent::_actionAdd($context);
    //make sure your file input name is file
     $file = KRequest::get('files.file', 'raw'); 
     $data = file_get_contents($file['tmp_name']);
     $entity->writeData($data);    
  }
}