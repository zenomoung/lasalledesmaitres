<?php

/** 
 * LICENSE: Anahita is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 * 
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Controller_Toolbar
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @copyright  2008 - 2010 rmdStudio Inc./Peerglobe Technology Inc
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @version    SVN: $Id: view.php 13650 2012-04-11 08:56:41Z asanieyan $
 * @link       http://www.anahitapolis.com
 */

/**
 * Set Toolbar
 *
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Controller_Toolbar
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @link       http://www.anahitapolis.com
 */
class ComFilesControllerToolbarSet extends ComMediumControllerToolbarDefault
{
	/**
     * Called after controller browse
     *
     * @param KEvent $event
     *
     * @return void
     */
    public function onAfterControllerBrowse(KEvent $event)
    {                
        $filter = $this->getController()->filter;
        $actor  = $this->getController()->actor;
        
        if ( $this->getController()->canAdd() && $filter != 'leaders' && $actor->files->getTotal() > 0 ) 
        {
            $this->addCommand('new');
        }        
    }
    
    /**
     * Set the toolbar commands
     * 
     * @return void
     */
    public function addToolbarCommands()
    { 
		$entity = $this->getController()->getItem();
		
		if ( $entity->authorize('vote') )
			$this->addCommand('vote');
		
		if ( $entity->owner->authorize('administration') )
		{
			//change cover
			$this->addCommand('changecover', JText::_('COM-FILES-ACTION-SET-CHANGE-COVER'))
			    ->getCommand('changecover')
			    ->dataTrigger('ChangeCover');
			
			//organize files
			$this->addCommand('organize', JText::_('COM-FILES-ACTION-SET-ORGANIZE'))
			    ->getCommand('organize')
			    ->dataTrigger('Organize');
			    
			$this->addAdministrationCommands();
		}
		
		if($entity->authorize('subscribe') || $entity->subscribed(get_viewer())) 
			$this->addCommand('subscribe');
		
		if ( $entity->authorize('delete') ) 
			$this->addCommand('delete');
	}
}