<?php

/** 
 * LICENSE: Anahita is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 * 
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Controller
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @copyright  2008 - 2010 rmdStudio Inc./Peerglobe Technology Inc
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @version    SVN: $Id: view.php 13650 2012-04-11 08:56:41Z asanieyan $
 * @link       http://www.anahitapolis.com
 */

/**
 * Album Controller
 *
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Controller
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @link       http://www.anahitapolis.com
 */
class ComFilesControllerSet extends ComMediumControllerDefault
{	 	
	/**
	 * Constructor.
	 *
	 * @param 	object 	An optional KConfig object with configuration options
	 */
	public function __construct(KConfig $config)
	{
		parent::__construct($config);
				
		$this->registerCallback(
			array('before.browse', 'before.read', 'before.add', 'before.addfile', 'before.removefile', 'before.updatefiles', 'before.updatecover' ), 
			array($this, 'fetchFile'));
			
		$this->registerCallback(
			array('after.addfile', 'after.removefile', 'after.updatefiles'), 
			array($this, 'reorder'));
	}
	
	/**
	 * Browse Albums
	 * 
	 * @return void;
	 */
	protected function _actionBrowse($context)
	{					
        $sets =  parent::_actionBrowse($context);
        
      	$sets->order('updateTime', 'DESC');
        
        if($this->file_id && $this->layout != 'selector')
        	$sets->where('files.id', '=', $this->file_id);
		
		return $sets;
	}
	
	/**
	 * Updates the files in a set given an array of ids
	 * 
	 * @param object POST data 
	 * @return object ComFilesDomainEntitySet
	 */
	protected function _actionUpdatefiles($context)
	{	
		$this->execute('addfile', $context);
		
		$file_ids = (array) KConfig::unbox( $context->data->file_id );
		
		foreach($this->getItem()->files as $file)
			if(!in_array($file->id, $file_ids))
				$this->getItem()->removeFile($file);
				
		if(!$this->getItem()->hasCover())
			$this->execute('updatecover', $context);		
				
		return $this->getItem();
	}
	
	/**
	 * Reorders the files in a set in respect with the order of ids
	 * 
	 * @param object POST data
	 * @return object ComFilesDomainEntitySet
	 */
	protected function _actionReorder($context)
	{
		$file_ids = (array) KConfig::unbox( $context->data->file_id );
		
		$this->getItem()->reorder($file_ids);

		return $this->getItem();
	}
	
	/**
	 * Adds a files to an set
	 * 
	 * @return object ComFilesDomainEntitySet
	 * @param object POST data
	 */
	protected function _actionAddfile($context)
	{	
		$this->getItem()->addFile($this->file);
		
		$this->setRedirect($this->getItem()->getURL());
		
		return $this->getItem();
	}
	
	/**
	 * Removes a list of files from an set
	 * 
	 * @return object ComFilesDomainEntitySet
	 * @param object POST data
	 */
	protected function _actionRemovefile($context)
	{		
        $lastFile = ($this->getItem()->files->getTotal() > 1) ? false : true;
        
		$this->getItem()->removeFile($this->file);
        
		if($lastFile)
		{
			$context->status = 205;
			return;
		}
		else
			return $this->getItem();
	}
	
	/**
	 * Updates the set cover
	 * 
	 * @return object ComFilesDomainEntitySet
	 * @param object POST data
	 */
	protected function _actionUpdatecover($context)
	{	
		$this->getItem()->setCover($this->files->top());
		return $this->getItem();
	}
	
	/**
	 * Fetches a file object given file_id as a GET request
	 * 
	 * @return null
	 * @param object POST data
	 */
	public function fetchFile(KCommandContext $context)
	{			
		$data = $context->data;
        
		$data->append(array(
			'file_id' => $this->file_id
		));
			
		$file_id = (array) KConfig::unbox( $data->file_id );	
        	   
		if ( !empty($file_id) ) 
        {
			$file = $this->actor->files->fetchSet(array('id'=>$file_id));
            					
			if ( count($file) === 0 )
				$file = null;
                
            $this->files = $this->file = $file;
		}
		
		return $this->file;
	}
	
	/**
	 * Fetches an entity
	 * 
	 * @return null
	 * @param object POST data
	 */	
	public function fetchEntity(KCommandContext $context)
	{
		if ( $context->action == 'addfile' )
		{		
			if ( $context->data->id )
				$this->id = $context->data->id;
			//clone the context so it's not touched
			$set = $this->__call('fetchEntity', array($context));
			
			if ( !$set )
			{
				$context->setError(null);
				//if the action is addfile and there are no sets then create an set
				$set = $this->add($context);
			}
				
			return $set;
		}
		else 
			return $this->__call('fetchEntity', array($context));
	}

//end class	
}