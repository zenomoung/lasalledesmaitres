<?php defined('KOOWA') or die ?>

<form id="set-select-form" data-behavior="FormValidator" method="post" action="<?= @route('view=set&oid='.$actor->id) ?>">
	<input type="hidden" value="addfile" name="action" />
	<?php foreach($files as $file): ?>
	<input type="hidden" name="file_id[]" value="<?= $file->id ?>" />
	<?php endforeach; ?>
	
	<?= @message(@text('COM-FILES-SET-SELECT-SIMPLE-INSTRUCTIONS')) ?>
		
	<?php if( $actor->sets->getTotal() ) : ?>
	<div class="clearfix">
		<label><?= @text('COM-FILES-SET-SELECT-ONE') ?></label>
		<div class="input">
			<select id="set" name="id" class="input-xlarge">
				<option value=""><?= @text('COM-FILES-SET-SELECT-NO-SET-IS-SELECTED') ?></option>
				<?php foreach($actor->sets as $set): ?>
				<option value="<?= $set->id ?>"><?= @escape($set->title) ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>
	<?php endif; ?>
	
	<?php if($actor->authorize('action','com_files:set:add')): ?>
	<div class="control-group">
		<label class="control-label" for="title"><?= @text('COM-FILES-ACTION-OR-CREATE-A-NEW-SET') ?></label>
		<div class="controls">
			<input data-validators="required" class="input-large" name="title" size="32" maxlength="100" type="text">
		</div>
	</div>
	<?php endif; ?>
	
	<div class="form-actions">
		<a class="btn" href="<?= @route('view=files&oid='.$actor->id) ?>"><?= @text('COM-FILES-ACTION-NO-THANK-YOU') ?></a> 
		<button data-trigger="add-files-to-set" class="btn btn-primary"><?= @text('COM-FILES-ACTION-SET-ADD-FILES') ?></button>
	</div>
</form>


<script>
Delegator.register('click', {
	
	'add-files-to-set' : function(event, el, api){
		event.stop();

		if(el.form.id.selectedIndex > 0)
			el.form.submit();

		if(el.form.title && el.form.get('validator').validate())
			el.form.submit();
	}
	
});
</script>