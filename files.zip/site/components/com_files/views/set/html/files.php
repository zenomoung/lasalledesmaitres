<?php defined('KOOWA') or die ?>

<?php $files = $set->files->order('fileSets.ordering'); ?>

<div id="set-mediums" class="set-mediums an-entities">
	<div class="media-grid">
		<?php foreach($files as $file) :?>
		<div class="thumbnail-wrapper <?= ($set->isCover($file)) ? 'cover' : '' ?>" mid="<?= $file->id ?>">
			<a class="thumbnail-link" href="<?= @route($file->getURL()) ?>" title="<?= @escape($file->title) ?>">
				<?php 
				$caption = htmlspecialchars($file->title, ENT_QUOTES).
				(($file->title && $file->description) ? ' :: ' : '').
				@helper('text.script', $file->description)
				?>
				<img caption="<?= $caption ?>" class="thumbnail" src="<?= $file->getPortraitURL('square') ?>" alt="<?= @escape($file->title) ?>" />
			</a>
		</div>
		<?php endforeach; ?>
	</div>
</div>