<?php defined('KOOWA') or die; ?>
<img id="set-cover" class="set-cover" alt="<?= @escape($set->title) ?>" src="<?= $set->getCoverSource('medium') ?>" />