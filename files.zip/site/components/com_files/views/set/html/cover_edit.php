<?php defined('KOOWA') or die('Restricted access'); ?>

<h4><?= @text('COM-FILES-SET-CHANGE-COVER') ?></h4>

<?= @message(@text('COM-FILES-SET-CHANGE-COVER-INSTRUCTIONS')) ?>

<div class="form-actions">
	<a data-trigger="Close" href="#" class="btn"><?= @text('LIB-AN-ACTION-CLOSE') ?></a>
</div>