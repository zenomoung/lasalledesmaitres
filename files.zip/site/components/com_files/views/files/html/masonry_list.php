<?php defined('KOOWA') or die('Restricted access');?>	
	
<?php foreach( $files as $file) : ?>
<?= @view('file')->layout('masonry')->file($file)->filter($filter) ?>
<?php endforeach; ?>