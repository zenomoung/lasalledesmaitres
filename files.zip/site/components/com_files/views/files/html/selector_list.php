<?php defined('KOOWA') or die('Restricted access');?>	
	
<?php if(count($files)) :?>
<?php foreach( $files as $file) : ?>
<div class="thumbnail-wrapper" mid="<?= $file->id ?>">
	<a class="thumbnail-link" href="<?= @route($file->getURL()) ?>" title="<?= @escape($file->title) ?>">
		<img class="thumbnail" src="<?= $file->getPortraitURL('square') ?>" />
	</a>
</div>
<?php endforeach; ?>
<?php else: ?>
<?= @message(@text('COM-FILES-NO-FILES-POSTED-YET')) ?>
<?php endif; ?>