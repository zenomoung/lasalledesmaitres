<?php defined('KOOWA') or die('Restricted access');?>	
	
<?php if(count($files)) : ?>
<div class="an-entities">
	<?php foreach( $files as $file) : ?>
	<?= @view('file')->layout('list')->file($file)->filter($filter) ?>
	<?php endforeach; ?>
</div>
<?php else: ?>
<?= @message(@text('COM-FILES-NO-FILES-POSTED-YET')) ?>
<?php endif; ?>

<?= @pagination($files, array('url'=>@route('layout=list'))) ?>