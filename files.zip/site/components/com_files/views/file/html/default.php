<?php defined('KOOWA') or die; ?>

<?php if( $file->authorize('edit') ) : ?>
<script src="com_files/js/fileset.js" />
<?php endif; ?>


<module position="sidebar-b" title="<?= @text('COM-FILES-FILE-RELATED-SETS') ?>">
<div id="sets-wrapper" oid="<?= $file->owner->id ?>" file_id="<?= $file->id ?>">
<?= @view('sets')->layout('module')->set('sets', $file->sets) ?>
</div>		
</module>		

<module position="sidebar-b" title="<?= @text('LIB-AN-META') ?>">	
	<ul class="an-meta">
		<li><?= sprintf( @text('LIB-AN-MEDIUM-AUTHOR'), @date($file->creationTime), @name($file->author)) ?></li>
		<li><?= sprintf( @text('LIB-AN-MEDIUM-EDITOR'), @date($file->updateTime), @name($file->editor)) ?></li>
		<li><?= sprintf( @text('COM-FILES-FILE-META-SETS'), $file->sets->getTotal()) ?></li>
		<li><?= sprintf( @text('LIB-AN-MEDIUM-NUMBER-OF-COMMENTS'), $file->numOfComments) ?></li>
	</ul>
</module>	
	
<?php if ( $actor->authorize('administration') ) : ?>
<module position="sidebar-b" title="<?= @text('COM-FILES-FILE-PRIVACY') ?>">		
	<?= @helper('ui.privacy',$file) ?>
</module>	
<?php endif; ?>

<?= @template('file') ?>

<?= @helper('ui.comments', $file) ?>
