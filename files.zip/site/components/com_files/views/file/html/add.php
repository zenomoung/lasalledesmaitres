<?php defined('KOOWA') or die('Restricted access'); ?>

<script  src="lib_anahita/js/vendors/plupload.js" />
<script  src="lib_anahita/js/uploader.js" />
<script  src="com_files/js/upload.js" />

<module position="sidebar-b" style="simple"></module>

<?php 
//check if flash uploader can work
$use_flash = ini_get('session.use_cookies') && !ini_get('session.use_only_cookies') && !ini_get('session.cookie_httponly');
?>

<div data-behavior="FileUploader" data-fileuploader-max-file-size="<?=get_config_value('files.uploadlimit',4)?>mb" data-fileuploader-form="form" data-fileuploader-plugin-url='<?=@route('view=sets&oid='.$actor->id.'&layout=add_files')?>'>
    <form class="upload-form" action="<?= @route( 'view=file&format=json&oid='.$actor->id.'&reset=1' ) ?>" method="post" enctype="multipart/form-data">
    	<div class="file-list">
    	    <?= @message(@text('COM-FILES-UPLOAD-NO-IMAGE-FILES-SELECTED')) ?>
    	</div>
    	
    	<?php if ( $actor->authorize('administration')) : ?>
		<div id="file-privacy-selector" class="control-group hide">
			<label class="control-label" for="privacy" id="privacy"><?= @text('LIB-AN-PRIVACY-FORM-LABEL') ?></label>
			<div class="controls">
				<?php $entity = @service('repos:files.file')->getEntity()->reset() ?>
				<?= @helper('ui.privacy',array('entity'=>$entity, 'auto_submit'=>false, 'options'=>$actor)) ?>
			</div>
		</div>
        <?php endif;?>	
    	
    	<div class="form-actions">
    	    <button class="select btn"><?=@text('COM-FILES-UPLOAD-CHOOSE-FILES')?></button>
    	    <button class="btn btn-primary"><?=@text('COM-FILES-UPLOAD')?></button>
    	</div>
    </form>
</div>
		