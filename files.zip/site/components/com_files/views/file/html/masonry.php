<?php defined('KOOWA') or die; ?>

<div class="an-entity an-record an-removable"">
	<?php if( $file->authorize('edit') ) : ?>
	<div class="entity-actions">
		<?= @helper('ui.commands', @commands('list')) ?>
	</div>
	<?php endif; ?>
	
	<div class="entity-portrait-medium" data-behavior="Mediabox">
		<?php 
			$rel = 'lightbox[actor-'.$file->owner->id.' 900 900]';
		
			$caption = htmlspecialchars($file->title, ENT_QUOTES).
			(($file->title && $file->description) ? ' :: ' : '').
			@helper('text.script', $file->description);			 
		?>
		<a title="<?= $caption ?>" href="<?= $file->getPortraitURL('medium') ?>" rel="<?= $rel ?>">			
			<img alt="<?= @escape($file->title) ?>" src="<?= $file->getPortraitURL('medium') ?>" />
		</a>
	</div>
	
	<?php if($file->title): ?>
	<h4 class="entity-title">
		<a title="<?= @escape($file->title) ?>" href="<?= @route($file->getURL()) ?>">
		<?= @escape($file->title) ?>
		</a>
	</h4>
	<?php endif; ?>
		
	<?php if($file->description): ?>
	<div class="entity-description">
	<?= @helper('text.truncate', strip_tags($file->description), array('length'=>200, 'read_more'=>true)); ?>
	</div>
	<?php endif; ?>
	
	<div class="clearfix">
		<div class="entity-portrait-square">
			<?= @avatar($file->author) ?>
		</div>
		
		<div class="entity-container">
			<div class="entity-meta">
				<?php if($filter == 'leaders'): ?>
				<div class="an-meta">
				<?= sprintf(@text('LIB-AN-MEDIUM-OWNER'), @name($file->owner)) ?>
				</div>
				<?php endif; ?>
			
				<div class="an-meta">
				<?= sprintf( @text('LIB-AN-MEDIUM-AUTHOR'), @date($file->creationTime), @name($file->author)) ?> 
				</div>
				
				<div class="an-meta">
				<a href="<?= @route($file->getURL()) ?>">
					<?= sprintf( @text('LIB-AN-MEDIUM-NUMBER-OF-COMMENTS'), $file->numOfComments) ?>
				</a>
				<?php if($file->lastCommenter): ?>
				 - <?= sprintf(@text('LIB-AN-MEDIUM-LAST-COMMENT-BY-X'), @name($file->lastCommenter), @date($file->lastCommentTime)) ?>
				<?php endif; ?>
				</div>
				
				<div class="vote-count-wrapper" id="vote-count-wrapper-<?= $file->id ?>">
					<?= @helper('ui.voters', $file); ?>
				</div>
			</div>
		</div>
	</div>
</div>
