<?php defined('KOOWA') or die; ?>

<?php @commands('toolbar') ?>

<div id="an-files-file" class="an-entity">
	
	<div class="entity-portrait-medium">
	<img alt="<?= @escape($file->title) ?>" src="<?= $file->getPortraitURL('medium') ?>" />
	</div>

	<div class="entity-title-wrapper">
		<h3 data-behavior="<?= $file->authorize('edit') ? 'Editable' : ''; ?>" class="entity-title <?= $file->authorize('edit') ? 'editable' : '' ?>" data-editable-options="{'url':'<?= @route($file->getURL()) ?>','name':'title', 'prompt':'<?= @text('COM-FILES-MEDIUM-TITLE-PROMPT') ?>'}">
			<?= @escape($file->title) ?>
		</h3>
	</div>

	<div class="entity-description-wrapper">
		<div data-behavior="<?= $file->authorize('edit') ? 'Editable' : ''; ?>" class="entity-description <?= ($file->authorize('edit')) ? 'editable' : '' ?>" data-editable-options="{'url':'<?= @route($file->getURL()) ?>','name':'description', 'input-type':'textarea', 'prompt':'<?= @text('COM-FILES-MEDIUM-DESCRIPTION-PROMPT') ?>'}">
			<?= @content($file->description) ?>
		</div>
	</div>
	
	<div class="entity-meta">
		<div class="an-meta" id="vote-count-wrapper-<?= $file->id ?>">
		<?= @helper('ui.voters', $file); ?>
		</div>
	</div>
</div>

