<?php $file = @service('repos:files.file')->getEntity()->reset() ?>

<form id="file-form" data-behavior="FormValidator ComposerForm" method="post" action="<?=@route($file->getURL().'&oid='.$actor->id)?>" enctype="multipart/form-data">
    <fieldset>
	    <legend><?= @text('COM-FILES-FILE-ADD')  ?></legend>		
		
		<div class="control-group">
			<label class="control-label" for="file"><?= @text('COM-FILES-COMPOSER-FILE-SELECT') ?></label>	
			<div class="controls">
				<input data-validators="required" type="file" name="file" />
			</div>
		</div>
				
		<div class="control-group">
			<label class="control-label" for="body"><?= @text('COM-FILES-COMPOSER-FILE-POST-DESCRIPTION') ?></label>
			<div class="controls">
				<textarea class="input-block-level" name="body" cols="10" rows="5" tabindex="2"></textarea>
			</div>
		</div>
				
		<div class="control-group">
			<label class="control-label" for="privacy" id="privacy"><?= @text('LIB-AN-PRIVACY-FORM-LABEL') ?></label>
			<div class="controls">
				<?= @helper('ui.privacy',array('entity'=>$file, 'auto_submit'=>false, 'options'=>$actor)) ?>
			</div>
		</div>
                		
	</fieldset>
	
    <div class="form-actions">
        <button class="btn btn-primary"><?=@text('LIB-AN-ACTION-POST')?></button>
    </div>
</form>