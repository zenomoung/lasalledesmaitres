<?php defined('KOOWA') or die; ?>

<div class="an-entity an-entity-portraiable an-record an-removable">
	
	<div class="entity-portrait-medium">
		<a title="<?= @escape($file->title) ?>" href="<?= @route($file->getURL()) ?>">			
			<img alt="<?= @escape($file->title) ?>" src="<?= $file->getPortraitURL('medium') ?>" />
		</a>
	</div>
	
	<div class="entity-title-wrapper">
		<h3 data-behavior="<?= $file->authorize('edit') ? 'Editable' : ''; ?>" class="entity-title <?= $file->authorize('edit') ? 'editable' : '' ?>" data-editable-options="{'url':'<?= @route($file->getURL()) ?>','name':'title', 'prompt':'<?= @text('COM-FILES-MEDIUM-TITLE-PROMPT') ?>'}">
		<?= @escape($file->title) ?>
        </h3>		
	</div>
	
	<div class="entity-description-wrapper <?= $file->authorize('edit') ? 'editable' : '' ?>">
		<div data-behavior="<?= $file->authorize('edit') ? 'Editable' : ''; ?>" class="entity-description <?= $file->authorize('edit') ? 'editable' : '' ?>" data-editable-options="{'url':'<?= @route($file->getURL()) ?>','name':'description', 'input-type':'textarea', 'prompt':'<?= @text('COM-FILES-MEDIUM-DESCRIPTION-PROMPT') ?>'}">
		<?= @escape($file->description) ?>
		</div>
	</div>
	
	<div class="entity-meta">
		<?php if($filter == 'leaders'): ?>
		<div class="an-meta">
		<?= sprintf(@text('LIB-AN-MEDIUM-OWNER'), @name($file->owner)) ?>
		</div>
		<?php endif; ?>
		
		<div class="an-meta">
			<?= sprintf( @text('LIB-AN-MEDIUM-AUTHOR'), @date($file->creationTime), @name($file->author)) ?>
		</div>
		
		<?php if($file->numOfComments): ?>
		<div class="an-meta">
		(<?= sprintf( @text('LIB-AN-MEDIUM-NUMBER-OF-COMMENTS'), $file->numOfComments) ?>) 
		<?php if($file->lastCommenter): ?>
		- <?= sprintf(@text('LIB-AN-MEDIUM-LAST-COMMENT-BY-X'), @name($file->lastCommenter), @date($file->lastCommentTime)) ?>
		<?php endif; ?>
		</div>
		<?php endif; ?>
		
		<div class="vote-count-wrapper" id="vote-count-wrapper-<?= $file->id ?>">
			<?= @helper('ui.voters', $file); ?>
		</div>
	</div>
	
	<div class="entity-actions">
		<?= @helper('ui.commands', @commands('list')) ?>
	</div>
</div>
