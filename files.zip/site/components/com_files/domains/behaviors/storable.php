﻿class ComFilesDomainBehaviorStorable extends LibBaseDomainBehaviorStorable
{
	protected function _initialize(KConfig $config)
	{
		$config->append(array(
			'attributes' 	=> array(
				'filename' => array('write'=>'protected'),
			)
		));
 
		parent::_initialize($config);
	}
  public function writeData($data)
  {     
     $path = md5($data);
     parent::writeData($data,$path,false);
     $this->_mixer->filename = $path;
  }
 
  public function readData()
  {
    $path = $this->_mixer->filename;
    return parent::readData($path, false);
  }
 
  protected function _beforeEntityDelete(KCommandContext $context)
  {
       $path = $context->entity->filename;
       $this->deletePath($path, false);
  }
 
 
}