<?php

/** 
 * LICENSE: Anahita is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 * 
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Domain_Entity
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @copyright  2008 - 2010 rmdStudio Inc./Peerglobe Technology Inc
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @version    SVN: $Id: view.php 13650 2012-04-11 08:56:41Z asanieyan $
 * @link       http://www.anahitapolis.com
 */

jimport('joomla.filesystem.file');

/**
 * Set Entity
 *
 * @category   Anahita
 * @package    Com_Files
 * @subpackage Domain_Entity
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @link       http://www.anahitapolis.com
 */
class ComFilesDomainEntitySet extends ComMediumDomainEntityMedium 
{
	
	/**
	 * Initializes the default configuration for the object
	 *
	 * Called from {@link __construct()} as a first step of object instantiation.
	 *
	 * @param KConfig $config An optional KConfig object with configuration options.
	 *
	 * @return void
	 */
	protected function _initialize(KConfig $config)
	{	
		$config->append(array(			
			'attributes' 	=> array(
				'name'				   => array('required'=>true),
				'coverFileIdentifier'  => 'filename'
			),
			'behaviors'		=> array(				
				'hittable'
			),			
			'relationships'	=> array(
				'files' => array('through'=>'edge')
			)
		));
					
		parent::_initialize($config);		
	}
	
	/**
	 * Obtains the image file source
	 * 
	 * @return string path to image source 
	 * @param $size file size. One of the constan sizes in the ComFilesDomainEntityFile class
	 */
	public function getCoverSource($size=ComFilesDomainEntityFile::SIZE_SQUARE)
	{
		if($this->hasCover())         
        {
            $filename  = $this->coverFileIdentifier;
            //remove the extension 
            $extension = JFile::getExt($filename);
            $name      = JFile:: stripExt($filename);
            $filename = $name.'_'.$size.'.'.$extension;                               
			return $this->owner->getPathURL('com_files/'.$filename);
        }
		
		return 'base://media/com_files/images/default.png';		
	}
	
	/**
	 * Adds a file to an set
	 * 
	 * @return true on success
	 * @param $file a ComFilesDomainEntityFile object
	 */
	public function addFile($file)
	{
		$files = AnHelperArray::getIterator($file);
		
		foreach($files as $file) 
		{
			if ( !$this->files->find($file) ) 
			{
			    $this->files->insert($file, array(
			         'author'=> $file->author
                ));
			}
		}

		if(!$this->hasCover())
		{
			$cover = is_array($files) ? $files[0] : $files->top();
			$this->setCover($cover);
		}
	}
	
	/**
	 * Removes a file or list of files from the set
	 * 
	 * @return null
	 * @param $file a ComFilesDomainEntityFile object
	 */
	public function removeFile($file)
	{
		$files = AnHelperArray::getIterator($file);
		
		foreach($files as $file) {
			if ( $edge = $this->files->find($file) )
				$edge->delete();
				
			if( $this->isCover($file) )
				$this->coverFileIdentifier = null;
		}
	}
	
	/**
	 * Orders the files in this set
	 * 
	 * @param array $file_ids
	 */
	public function reorder($file_ids)
	{		
		foreach($file_ids as $index=>$file_id)
		{
			if($edge = $this->getService('repos://site/files.edge')->fetch(array('set'=>$this,'file.id'=>$file_id)))
				$edge->ordering = $index + 1;
		}
	}
	
	/**
	 * Return true or false if the set has a cover
	 * 
	 * @return boolean
	 */
	public function hasCover()
	{
		return strlen($this->coverFileIdentifier) > 0;
	}
	
	/**
	 * Determines if the given file is the set cover or not.
	 * 
	 * @param $file a ComFilesDomainEntityFile object
	 * @return boolean
	 */
	public function isCover($file)
	{
		return $this->coverFileIdentifier == $file->filename;
	}
	
	/**
	 * Sets the set cover image
	 * 
	 * @return null
	 * @param $file a ComFilesDomainEntityFile object
	 */
	public function setCover($file)
	{
		$this->coverFileIdentifier = $file->filename;
	}
	
	/**
	 * Gets number of files in this set
	 * 
	 * @return integer value
	 */
	public function getFileCount()
	{
		return $this->getValue('file_count', 0);
	}
}