<?php defined('KOOWA') or die('Restricted access');
/**
 * @version		$Id
 * @category	Anahita
 * @package		Anahita_Social_Applications
 * @subpackage	Files
 * @copyright	Copyright (C) 2008 - 2010 rmdStudio Inc. and Peerglobe Technology Inc. All rights reserved.
 * @license		GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @link     	http://www.anahitapolis.com
 */

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.cache.cache' );


class plgContentAn_Files extends JPlugin
{
	function onPrepareContent( &$article, &$params, $limitstart )
	{
		global $mainframe;
		
		// simple performance check to determine whether bot should process further
    	if ( strpos( $article->text, '{an-files' ) === false ) {
    		return true;
    	}
    	
    	// define the regular expression for the bot
    	$regex = "#{an-files(.*?)}#s";
    	
    	// find all instances of plugin and put in $matches
    	preg_match_all( "#{an-files(.*?)}#s", $article->text, $matches );
    	
    	// Number of plugins
     	$count = count( $matches[0] );
     	
     	if($count)
     		$this->plgContentDisplayImages( $article, $matches, $count );
     		
     	return true;
	}
	
	function plgContentDisplayImages( &$article, &$matches, $count ) 
	{
		JHTML::script('lib_anahita/js/vendors/mediabox.js', 'media/', false);
		
		$app = JFactory::getApplication();		

		for ( $i=0; $i < $count; $i++ )
    	{
    		if (@$matches[1][$i]) 
    		{
    			$inline_params = $matches[1][$i];
    			
    			// get set_id
        		$set_matches = array();
        		$set_id = null;
        		preg_match( '# set_id="(.*?)"#s', $inline_params, $set_matches );
        		if (isset($set_matches[1])) $set_id = (int) trim($set_matches[1]);
    		}
    		
    		if($set_id)
    		{
    			//load set object
    			$set = KService::get('repos:files.set')->getQuery()->disableChain()->id($set_id)->fetch();
    			
    			if($set)
    			{
    				$do_cache = $this->params->get('cache', true);
    				if ( $do_cache )
    				{
	    				$cache = JFactory::getCache('plg_an_files');
	    				$cache->setLifeTime( $app->getCfg('cachetime') * 100); //cache one day
	    				$text = $cache->get(array($this, 'getSetHtml'), array($set), md5($set->id));    					
    				} else {
    					$text = $this->getSetHtml($set);
    				}

    			}
    			else 	
    				$text = '<div class="alert alert-error">'.JText::_('LIB-AN-NO-RECORD-AVAILABLE').'</div>';		
    			    			
    			$article->text = str_replace( $matches[0][$i], $text, $article->text );	
    		}
    	}
	}
	
	function getSetHtml($set)
	{
	    if($set->id )
	    {
	        $files = $set->files->getQuery()->order('fileSets.ordering')->disableChain()->fetchSet();
	        
	        if ( count($files) === 0 )
	            return;
	        
			$text   = '<div class="an-files-plugin">';
	    	$text  .= '<div class="media-grid" data-behavior="Mediabox">';						
			
			foreach($files as $file)
			{	
				$caption = htmlspecialchars($file->title, ENT_QUOTES).
				(($file->title && $file->description) ? ' :: ' : '').
                
				KService::get('com://site/base.template.helper.text')->script($file->description);
				
				$text .= '<div>';
				$text .= '<a rel="lightbox[set-'.$set->id.' 900 900]" title="'.$caption.'" href="'.$file->getPortraitURL('medium').'">';
				$text .= '<img alt="'.htmlspecialchars($file->title, ENT_QUOTES).'" class="set thumbnail" src="'.$file->getPortraitURL('square').'" />';
				$text .= '</a>';
				$text .= '</div>';
			}	
			
			$text .= '</div></div>';
	
			return $text;
	    }
	    
	    return '';
	}
	
//end class	
}



