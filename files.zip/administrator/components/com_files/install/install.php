<?php

/** 
 * LICENSE: Anahita is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 * 
 * @category   Anahita
 * @package    Com_Files
 * @author     Arash Sanieyan <ash@anahitapolis.com>
 * @author     Rastin Mehr <rastin@anahitapolis.com>
 * @copyright  2008 - 2010 rmdStudio Inc./Peerglobe Technology Inc
 * @license    GNU GPLv3 <http://www.gnu.org/licenses/gpl-3.0.html>
 * @version    SVN: $Id: resource.php 11985 2012-01-12 10:53:20Z asanieyan $
 * @link       http://www.anahitapolis.com
 */

function com_install($intaller) 
{
    //doesn't exists create a menu item
    if ( !$intaller->get('component_exists') ) 
    {        
        if ( dbexists('SELECT * FROM #__menu_types WHERE menutype LIKE "viewer"') ) 
        {
            $component_id = dbfetch("SELECT id from #__components WHERE `option` LIKE 'com_files'", KDatabase::FETCH_FIELD);
            dbexec("INSERT INTO `#__menu` VALUES(NULL, 'viewer', 'Files', 'files', 'index.php?option=com_files&view=files&oid=viewer', 'component', 1, 0, $component_id, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 1, 0, 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0)");   
        }
    }
}